# Mi Paquete

Un paquete para modelar clientes en una página de compras utilizando Programación Orientada a Objetos en Python.